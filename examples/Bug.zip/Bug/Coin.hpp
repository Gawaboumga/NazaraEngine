#ifndef __COIN_HPP__
#define __COIN_HPP__

#include <Nazara/Graphics/Sprite.hpp>

#include <NDK/Components/GraphicsComponent.hpp>

bool CreateCoin(Ndk::World& world)
{
	Nz::String coin{ "coin" };
	Nz::Vector2ui coinSize = Nz::Vector2ui(16, 16);

	if (!Nz::ImageLibrary::Has(coin))
	{
		auto image = Nz::Image::New();
		if (!image->LoadFromFile("smb_enemies_sheet.png"))
		{
			NazaraError("Error while loading assets");
			return false;
		}

		Nz::ImageLibrary::Register(coin, image);
	}

	if (!Nz::SpriteLibrary::Has(coin))
	{
		auto image = Nz::ImageLibrary::Get(coin);
		auto coinImage = Nz::Image::New(image->GetType(), image->GetFormat(), coinSize.x, coinSize.y);
		Nz::Boxui box {
			0, 32, 0, // Hard coded position of coin
			coinSize.x, coinSize.y, 1
		};
		coinImage->Copy(*image.Get(), box, Nz::Vector3ui::Zero());

		auto coinTexture = Nz::Texture::New(*coinImage.Get());
		Nz::TextureLibrary::Register(coin, coinTexture);

		// No idea why I need to do that
		#if WITH_BUG
		Nz::MaterialRef material = Nz::MaterialLibrary::Get("Default");
		material->SetFaceFilling(Nz::FaceFilling_Fill);
		material->SetDiffuseMap(coinTexture);
		Nz::SpriteRef coinSprite = Nz::Sprite::New(material);
		Nz::SpriteLibrary::Register(coin, coinSprite);
		#else
		auto coinSprite = Nz::Sprite::New(coinTexture.Get());
		Nz::SpriteLibrary::Register(coin, coinSprite);
		#endif
	}

	auto coinSprite = Nz::SpriteLibrary::Get(coin);

	auto entity = world.CreateEntity();
	auto& nodeComponent = entity->AddComponent<Ndk::NodeComponent>();
	nodeComponent.SetPosition(350, 350);
	auto& graphicsComponent = entity->AddComponent<Ndk::GraphicsComponent>();
	graphicsComponent.Attach(coinSprite);

	return true;
}

#endif // __COIN_HPP__
