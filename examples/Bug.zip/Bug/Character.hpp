#ifndef __CHARACTER_HPP__
#define __CHARACTER_HPP__

#include <Nazara/Graphics/Sprite.hpp>

#include <NDK/Components/GraphicsComponent.hpp>

bool CreateCharacter(Ndk::World& world)
{
	Nz::String mario{ "Mario" };
	Nz::Vector2ui marioSize = Nz::Vector2ui(16, 16);

	if (!Nz::ImageLibrary::Has(mario))
	{
		auto image = Nz::Image::New();
		if (!image->LoadFromFile("smb_mario_sheet.png"))
		{
			NazaraError("Error while loading assets");
			return false;
		}

		Nz::ImageLibrary::Register(mario, image);
	}

	if (!Nz::SpriteLibrary::Has(mario))
	{
		auto image = Nz::ImageLibrary::Get(mario);
		auto marioImage = Nz::Image::New(image->GetType(), image->GetFormat(), marioSize.x, marioSize.y);
		Nz::Boxui box {
			208, 0, 0, // Hard coded position of Mario
			marioSize.x, marioSize.y, 1
		};
		marioImage->Copy(*image.Get(), box, Nz::Vector3ui::Zero());

		auto marioTexture = Nz::Texture::New(*marioImage.Get());
		Nz::TextureLibrary::Register(mario, marioTexture);

		// No idea why I need to do that
		#if WITH_BUG
		Nz::MaterialRef material = Nz::MaterialLibrary::Get("Default");
		material->SetFaceFilling(Nz::FaceFilling_Fill);
		material->SetDiffuseMap(marioTexture);
		Nz::SpriteRef marioSprite = Nz::Sprite::New(material);
		Nz::SpriteLibrary::Register(mario, marioSprite);
		#else
		auto marioSprite = Nz::Sprite::New(marioTexture.Get());
		Nz::SpriteLibrary::Register(mario, marioSprite);
		#endif
	}

	auto marioSprite = Nz::SpriteLibrary::Get(mario);

	auto entity = world.CreateEntity();
	auto& nodeComponent = entity->AddComponent<Ndk::NodeComponent>();
	nodeComponent.SetPosition(200, 200);
	auto& graphicsComponent = entity->AddComponent<Ndk::GraphicsComponent>();
	graphicsComponent.Attach(marioSprite);

	return true;
}

#endif // __CHARACTER_HPP__
