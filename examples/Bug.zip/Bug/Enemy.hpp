#ifndef __ENEMY_HPP__
#define __ENEMY_HPP__

#include <Nazara/Graphics/Sprite.hpp>

#include <NDK/Components/GraphicsComponent.hpp>

bool CreateEnemy(Ndk::World& world)
{
	Nz::String goompa{ "goompa" };
	Nz::Vector2ui goompaSize = Nz::Vector2ui(16, 16);

	if (!Nz::ImageLibrary::Has(goompa))
	{
		auto image = Nz::Image::New();
		if (!image->LoadFromFile("smb_enemies_sheet.png"))
		{
			NazaraError("Error while loading assets");
			return false;
		}

		Nz::ImageLibrary::Register(goompa, image);
	}

	if (!Nz::SpriteLibrary::Has(goompa))
	{
		auto image = Nz::ImageLibrary::Get(goompa);
		auto goompaImage = Nz::Image::New(image->GetType(), image->GetFormat(), goompaSize.x, goompaSize.y);
		Nz::Boxui box {
			0, 4, 0, // Hard coded position of Goompa
			goompaSize.x, goompaSize.y, 1
		};
		goompaImage->Copy(*image.Get(), box, Nz::Vector3ui::Zero());

		auto goompaTexture = Nz::Texture::New(*goompaImage.Get());
		Nz::TextureLibrary::Register(goompa, goompaTexture);

		// No idea why I need to do that
		#if WITH_BUG
		Nz::MaterialRef material = Nz::MaterialLibrary::Get("Default");
		material->SetFaceFilling(Nz::FaceFilling_Fill);
		material->SetDiffuseMap(goompaTexture);
		Nz::SpriteRef goompaSprite = Nz::Sprite::New(material);
		Nz::SpriteLibrary::Register(goompa, goompaSprite);
		#else
		auto goompaSprite = Nz::Sprite::New(goompaTexture.Get());
		Nz::SpriteLibrary::Register(goompa, goompaSprite);
		#endif
	}

	auto goompaSprite = Nz::SpriteLibrary::Get(goompa);

	auto entity = world.CreateEntity();
	auto& nodeComponent = entity->AddComponent<Ndk::NodeComponent>();
	nodeComponent.SetPosition(400, 400);
	auto& graphicsComponent = entity->AddComponent<Ndk::GraphicsComponent>();
	graphicsComponent.Attach(goompaSprite);

	return true;
}

#endif // __ENEMY_HPP__
